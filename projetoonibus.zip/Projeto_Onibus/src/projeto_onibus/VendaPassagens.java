package projeto_onibus;

import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author Usuario
 */
public class VendaPassagens extends javax.swing.JFrame {
    
private boolean[] poltronasOcupadas = new boolean[40];
        

    
    
    public VendaPassagens() {
        initComponents();
        this.setTitle("Listar Vendas");
        this.setResizable(false);
        this.setLocationRelativeTo(null);
        this.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        
       for(int i = 0; i < poltronasOcupadas.length; i++) {
        poltronasOcupadas[i] = false;
    }
       
       for(Passagem p : MenuPrincipal.passagem) {
        int numPoltrona = Integer.parseInt(p.getNumerodapoltrona().replaceAll("[^0-9]", ""));
        if(numPoltrona > 0 && numPoltrona <= 40) {
            poltronasOcupadas[numPoltrona-1] = true;
        }
    }
       
        
        DefaultTableModel m = new DefaultTableModel();
        m.addColumn("Possiveis destinos");
        
        
        //Preencher a TABELA
        //for(int i = 0; i< MenuForm.pessoa.size();; i++)
        
         for(Cidade p : MenuPrincipal.cidade){
            m.addRow(
                new Object[]{ p.getNome(),p.getCodigoidentificador(),  p.getEstado() }
           );
        }
       tabVendas.setModel(m);
       
       tabVendas.addMouseListener(new java.awt.event.MouseAdapter() {
        @Override
        public void mouseClicked(java.awt.event.MouseEvent evt) {
            int row = tabVendas.getSelectedRow(); // Obtém a linha selecionada
            if (row != -1) { // Verifica se há uma linha válida selecionada
                txtCidadedeDestino.setText(tabVendas.getValueAt(row, 0).toString());
                
               }
        }
    });
    }
   
    
   
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        lblVendas = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        tabVendas = new javax.swing.JTable();
        lblCidadedeOrigem = new javax.swing.JLabel();
        txtCidadedeOrigem = new javax.swing.JTextField();
        txtCidadedeDestino = new javax.swing.JTextField();
        lblCidadedeDestino = new javax.swing.JLabel();
        lblDatatdaViagem = new javax.swing.JLabel();
        txtDatadaViagem = new javax.swing.JTextField();
        lblNumerodaPoltrona = new javax.swing.JLabel();
        lblNome = new javax.swing.JLabel();
        txtCpf = new javax.swing.JTextField();
        lblCpf = new javax.swing.JLabel();
        txtNome = new javax.swing.JTextField();
        btnSalvar = new javax.swing.JButton();
        btnSair = new javax.swing.JButton();
        cmbPoltrona = new javax.swing.JComboBox<>();
        txtNPoltrona = new javax.swing.JTextField();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        lblVendas.setFont(new java.awt.Font("Segoe UI", 0, 24)); // NOI18N
        lblVendas.setText("Vendas");

        tabVendas.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane1.setViewportView(tabVendas);

        lblCidadedeOrigem.setText("Cidade de Origem");

        txtCidadedeOrigem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtCidadedeOrigemActionPerformed(evt);
            }
        });

        txtCidadedeDestino.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtCidadedeDestinoActionPerformed(evt);
            }
        });

        lblCidadedeDestino.setText("Cidade de Destino");

        lblDatatdaViagem.setText("Data da Viagem");

        lblNumerodaPoltrona.setText("Número da Poltrona (1 - 40)");

        lblNome.setText("Nome");

        txtCpf.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtCpfActionPerformed(evt);
            }
        });

        lblCpf.setText("CPF");

        txtNome.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtNomeActionPerformed(evt);
            }
        });

        btnSalvar.setText("Salvar");
        btnSalvar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSalvarActionPerformed(evt);
            }
        });

        btnSair.setText("Sair");
        btnSair.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSairActionPerformed(evt);
            }
        });

        cmbPoltrona.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Poltrona 1", "Poltrona 2", "Poltrona 3", "Poltrona 4", "Poltrona 5", "Poltrona 6", "Poltrona 7", "Poltrona 8", "Poltrona 9", "Poltrona 10", "Poltrona 11", "Poltrona 12", "Poltrona 13", "Poltrona 14", "Poltrona 15", "Poltrona 16", "Poltrona 17", "Poltrona 18", "Poltrona 19", "Poltrona 20", "Poltrona 21", "Poltrona 22", "Poltrona 23", "Poltrona 24", "Poltrona 25", "Poltrona 26", "Poltrona 27", "Poltrona 28", "Poltrona 29", "Poltrona 30", "Poltrona 31", "Poltrona 32", "Poltrona 33", "Poltrona 34", "Poltrona 35", "Poltrona 36", "Poltrona 37", "Poltrona 38", "Poltrona 39", "Poltrona 40" }));
        cmbPoltrona.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cmbPoltronaActionPerformed(evt);
            }
        });

        txtNPoltrona.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtNPoltronaActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addGap(272, 272, 272)
                                .addComponent(lblVendas, javax.swing.GroupLayout.PREFERRED_SIZE, 103, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(layout.createSequentialGroup()
                                .addGap(177, 177, 177)
                                .addComponent(btnSalvar, javax.swing.GroupLayout.PREFERRED_SIZE, 141, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addComponent(btnSair, javax.swing.GroupLayout.PREFERRED_SIZE, 141, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addGroup(layout.createSequentialGroup()
                        .addContainerGap()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jScrollPane1)
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(txtNome, javax.swing.GroupLayout.PREFERRED_SIZE, 321, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addGroup(layout.createSequentialGroup()
                                        .addGap(6, 6, 6)
                                        .addComponent(lblNome, javax.swing.GroupLayout.PREFERRED_SIZE, 54, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(txtCpf, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 321, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addGroup(layout.createSequentialGroup()
                                        .addComponent(lblCpf, javax.swing.GroupLayout.PREFERRED_SIZE, 70, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGap(0, 0, Short.MAX_VALUE))))
                            .addComponent(lblCidadedeDestino)
                            .addComponent(lblCidadedeOrigem)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(txtCidadedeOrigem, javax.swing.GroupLayout.PREFERRED_SIZE, 321, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(lblNumerodaPoltrona)
                                    .addComponent(txtDatadaViagem, javax.swing.GroupLayout.PREFERRED_SIZE, 321, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(lblDatatdaViagem)))
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(txtCidadedeDestino, javax.swing.GroupLayout.PREFERRED_SIZE, 321, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(cmbPoltrona, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                        .addGap(0, 0, Short.MAX_VALUE)
                                        .addComponent(txtNPoltrona, javax.swing.GroupLayout.PREFERRED_SIZE, 321, javax.swing.GroupLayout.PREFERRED_SIZE)))))))
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(lblVendas)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblCidadedeOrigem)
                    .addComponent(lblDatatdaViagem))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txtCidadedeOrigem, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txtDatadaViagem, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblCidadedeDestino)
                    .addComponent(lblNumerodaPoltrona))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(txtCidadedeDestino)
                    .addComponent(cmbPoltrona, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(txtNPoltrona, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(lblCpf)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(txtCpf, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(lblNome)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(txtNome, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 26, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnSair)
                    .addComponent(btnSalvar))
                .addGap(17, 17, 17))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void txtCidadedeDestinoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtCidadedeDestinoActionPerformed
        // TODO add your handling code here:
        
    }//GEN-LAST:event_txtCidadedeDestinoActionPerformed

    private void txtCpfActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtCpfActionPerformed
        // TODO add your handling code here:
        
    }//GEN-LAST:event_txtCpfActionPerformed

    private void txtNomeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtNomeActionPerformed
        // TODO add your handling code here:
        
    }//GEN-LAST:event_txtNomeActionPerformed

    private void btnSalvarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSalvarActionPerformed
        // TODO add your handling code here:
        
       
       String cidadedeorigem = txtCidadedeOrigem.getText();
       String cidadedestino = txtCidadedeDestino.getText();
       String dataviagem = txtDatadaViagem.getText();
       String numerodapoltrona = cmbPoltrona.getSelectedItem().toString();
       String nome = txtNome.getText();
       String cpf = txtCpf.getText();
       
        
       
       
        //Adicionar na List<Pessoa>
        MenuPrincipal.passagem.add(
                new Passagem (cidadedeorigem,cidadedestino, dataviagem, numerodapoltrona , nome, cpf)
        );
        
        JOptionPane.showMessageDialog(null,
                "Operação realizada com sucesso!"
        );
         this.dispose();
    }//GEN-LAST:event_btnSalvarActionPerformed

    private void txtCidadedeOrigemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtCidadedeOrigemActionPerformed
        // TODO add your handling code here:
        
    }//GEN-LAST:event_txtCidadedeOrigemActionPerformed

    private void btnSairActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSairActionPerformed
        // TODO add your handling code here:
        this.dispose();
    }//GEN-LAST:event_btnSairActionPerformed

    private void cmbPoltronaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cmbPoltronaActionPerformed
        // TODO add your handling code here:
           String numerodapoltrona = cmbPoltrona.getSelectedItem().toString();
           txtNPoltrona.setText(numerodapoltrona);
           
           
        
    }//GEN-LAST:event_cmbPoltronaActionPerformed

    private void txtNPoltronaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtNPoltronaActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtNPoltronaActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(VendaPassagens.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(VendaPassagens.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(VendaPassagens.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(VendaPassagens.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new VendaPassagens().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnSair;
    private javax.swing.JButton btnSalvar;
    private javax.swing.JComboBox<String> cmbPoltrona;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JLabel lblCidadedeDestino;
    private javax.swing.JLabel lblCidadedeOrigem;
    private javax.swing.JLabel lblCpf;
    private javax.swing.JLabel lblDatatdaViagem;
    private javax.swing.JLabel lblNome;
    private javax.swing.JLabel lblNumerodaPoltrona;
    private javax.swing.JLabel lblVendas;
    private javax.swing.JTable tabVendas;
    private javax.swing.JTextField txtCidadedeDestino;
    private javax.swing.JTextField txtCidadedeOrigem;
    private javax.swing.JTextField txtCpf;
    private javax.swing.JTextField txtDatadaViagem;
    private javax.swing.JTextField txtNPoltrona;
    private javax.swing.JTextField txtNome;
    // End of variables declaration//GEN-END:variables
}
