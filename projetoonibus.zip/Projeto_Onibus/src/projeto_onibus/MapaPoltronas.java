package projeto_onibus;

import javax.swing.JFrame;
import javax.swing.table.DefaultTableModel;
import projeto_onibus.MenuPrincipal;
import projeto_onibus.Passagem;


public class MapaPoltronas extends javax.swing.JFrame {
    
    public MapaPoltronas() {
        
        initComponents();
        this.setTitle("Mapa das poltronas");
        this.setResizable(false);
        this.setLocationRelativeTo(null);
        this.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        
        // Criando o modelo da tabela
        DefaultTableModel m = new DefaultTableModel();
        m.addColumn("Mapa das poltronas");

        // Preenchendo com as poltronas da lista
        for (Passagem p : MenuPrincipal.passagem) {
            m.addRow(new Object[]{p.getNumerodapoltrona()});
        }

        // Atribuindo o modelo à tabela (fora do for!)
        tabIndisponivel.setModel(m);

        // Adicionando clique na tabela (fora do for também!)
        tabIndisponivel.addMouseListener(new java.awt.event.MouseAdapter() {
            @Override
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                int row = tabIndisponivel.getSelectedRow();
                if (row != -1) {
                    String poltrona = m.getValueAt(row, 0).toString();
                    System.out.println("Poltrona clicada: " + poltrona);
                    // Aqui você pode remover da tabela ou mover pra comboBox, etc
                }
            }
        });
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        btnVoltar = new javax.swing.JButton();
        lblPoltronasDisponiveis = new javax.swing.JLabel();
        lblMapadasPoltronas = new javax.swing.JLabel();
        lblPoltronasIndisponiveis = new javax.swing.JLabel();
        cmbPoltronaDisponiveis = new javax.swing.JComboBox<>();
        jScrollPane1 = new javax.swing.JScrollPane();
        tabIndisponivel = new javax.swing.JTable();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        btnVoltar.setText("voltar");
        btnVoltar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnVoltarActionPerformed(evt);
            }
        });

        lblPoltronasDisponiveis.setFont(new java.awt.Font("Segoe UI", 0, 24)); // NOI18N
        lblPoltronasDisponiveis.setText("Poltronas disponiveis");

        lblMapadasPoltronas.setFont(new java.awt.Font("Segoe UI", 0, 24)); // NOI18N
        lblMapadasPoltronas.setText("Mapa das Poltronas");

        lblPoltronasIndisponiveis.setFont(new java.awt.Font("Segoe UI", 0, 24)); // NOI18N
        lblPoltronasIndisponiveis.setText("Poltronas indisponiveis");

        cmbPoltronaDisponiveis.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Poltrona 1", "Poltrona 2", "Poltrona 3", "Poltrona 4", "Poltrona 5", "Poltrona 6", "Poltrona 7", "Poltrona 8", "Poltrona 9", "Poltrona 10", "Poltrona 11", "Poltrona 12", "Poltrona 13", "Poltrona 14", "Poltrona 15", "Poltrona 16", "Poltrona 17", "Poltrona 18", "Poltrona 19", "Poltrona 20", "Poltrona 21", "Poltrona 22", "Poltrona 23", "Poltrona 24", "Poltrona 25", "Poltrona 26", "Poltrona 27", "Poltrona 28", "Poltrona 29", "Poltrona 30", "Poltrona 31", "Poltrona 32", "Poltrona 33", "Poltrona 34", "Poltrona 35", "Poltrona 36", "Poltrona 37", "Poltrona 38", "Poltrona 39", "Poltrona 40" }));
        cmbPoltronaDisponiveis.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cmbPoltronaDisponiveisActionPerformed(evt);
            }
        });

        tabIndisponivel.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane1.setViewportView(tabIndisponivel);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(225, 225, 225)
                .addComponent(lblMapadasPoltronas)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(layout.createSequentialGroup()
                .addGap(52, 52, 52)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(btnVoltar, javax.swing.GroupLayout.PREFERRED_SIZE, 86, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(cmbPoltronaDisponiveis, javax.swing.GroupLayout.PREFERRED_SIZE, 244, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(lblPoltronasDisponiveis))
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addGap(57, 57, 57)
                                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 320, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(lblPoltronasIndisponiveis)
                                .addGap(33, 33, 33)))))
                .addGap(0, 25, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(lblMapadasPoltronas)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblPoltronasIndisponiveis)
                    .addComponent(lblPoltronasDisponiveis))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(cmbPoltronaDisponiveis, javax.swing.GroupLayout.PREFERRED_SIZE, 46, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 180, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addComponent(btnVoltar)
                .addGap(113, 113, 113))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnVoltarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnVoltarActionPerformed
        // TODO add your handling code here:
                 this.dispose();
    }//GEN-LAST:event_btnVoltarActionPerformed

    private void cmbPoltronaDisponiveisActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cmbPoltronaDisponiveisActionPerformed
        // TODO add your handling code here:
          String numerodapoltrona = cmbPoltronaDisponiveis.getSelectedItem().toString();

    // Remove da combo de disponíveis
    cmbPoltronaDisponiveis.removeItem(numerodapoltrona);


    }//GEN-LAST:event_cmbPoltronaDisponiveisActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(MapaPoltronas.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(MapaPoltronas.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(MapaPoltronas.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(MapaPoltronas.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new MapaPoltronas().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnVoltar;
    private javax.swing.JComboBox<String> cmbPoltronaDisponiveis;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JLabel lblMapadasPoltronas;
    private javax.swing.JLabel lblPoltronasDisponiveis;
    private javax.swing.JLabel lblPoltronasIndisponiveis;
    private javax.swing.JTable tabIndisponivel;
    // End of variables declaration//GEN-END:variables

}