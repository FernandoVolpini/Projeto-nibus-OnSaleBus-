package projeto_onibus;

// Classe que representa a passagem
public class Passagem {
    private String cidadedeorigem;
    private String cidadedestino;
    private String dataviagem;
    private String numerodapoltrona;
    private String nome;
    private String cpf;

    public Passagem() {
    }

    
    
    public Passagem(String cidadedeorigem, String cidadedestino, String dataviagem, String numerodapoltrona, String nome, String cpf) {
        this.cidadedeorigem = cidadedeorigem;
        this.cidadedestino = cidadedestino;
        this.dataviagem = dataviagem;
        this.numerodapoltrona = numerodapoltrona;
        this.nome = nome;
        this.cpf = cpf;
    }

    public String getCidadedeorigem() {
        return cidadedeorigem;
    }

    public void setCidadedeorigem(String cidadedeorigem) {
        this.cidadedeorigem = cidadedeorigem;
    }

    public String getCidadedestino() {
        return cidadedestino;
    }

    public void setCidadedestino(String cidadedestino) {
        this.cidadedestino = cidadedestino;
    }

    public String getDataviagem() {
        return dataviagem;
    }

    public void setDataviagem(String dataviagem) {
        this.dataviagem = dataviagem;
    }

    public String getNumerodapoltrona() {
        return numerodapoltrona;
    }

    public void setNumerodapoltrona(String numerodapoltrona) {
        this.numerodapoltrona = numerodapoltrona;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getCpf() {
        return cpf;
    }

    public void setCpf(String cpf) {
        this.cpf = cpf;
    }

    
   

  

    @Override
    public String toString() {
        return String.format("Cidade de origem: %s\nCidade de destino: %s\nData da viagem: %s\nNúmero da poltrona: %s\nNome: %s\nCPF: %s", 
                cidadedeorigem, cidadedestino, dataviagem, numerodapoltrona, nome, cpf);
    }
}
