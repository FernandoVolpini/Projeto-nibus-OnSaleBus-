package projeto_onibus;

import java.util.ArrayList;
import java.util.List;

public class MapadasPoltronas {
    private String poltronasdisponiveis;
    private String poltronasindisponiveis;

    public MapadasPoltronas() {
        
    }
    
    public MapadasPoltronas(String poltronasdisponiveis, String poltronasindisponiveis) {
        this.poltronasdisponiveis = poltronasdisponiveis;
        this.poltronasindisponiveis = poltronasindisponiveis;
    }

    
    public String getPoltronasdisponiveis() {
        return poltronasdisponiveis;
    }

    public void setPoltronasdisponiveis(String poltronasdisponiveis) {
        this.poltronasdisponiveis = poltronasdisponiveis;
    }

    public String getPoltronasindisponiveis() {
        return poltronasindisponiveis;
    }

    public void setPoltronasindisponiveis(String poltronasindisponiveis) {
        this.poltronasindisponiveis = poltronasindisponiveis;
        
    }

    @Override
    public String toString() {
        return String.format("Poltronas Disponiveis: %s\nPoltronas Indisponiveis: %s", poltronasdisponiveis, poltronasindisponiveis);
    }
    
}
